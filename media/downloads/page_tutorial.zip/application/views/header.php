<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >
	<head>
		<title><?=$title?></title>
		<?=html::stylesheet('css/layout.css')?>
		<?=html::stylesheet('css/style.css')?>
		<?=html::stylesheet('css/menu.css')?>

		<?=html::script('js/jquery.js')?>
		<?=html::script('js/jquery.livequery.js')?>
		<?=html::script('js/effects.js')?>
	</head>
	<body>
		<div id="menu">
			<ul class="nav">
				<?php foreach ($menu["menu"] as $url => $title):?>
				<li><?=html::anchor($url, htmlentities($title))?>
					<?php if (isset($menu["submenu"][$url])):?><ul>
						<?php foreach ($menu["submenu"][$url] as $child_url => $title):?>
						<li><?=html::anchor($child_url, htmlentities($title))?></li>
						<?php endforeach; ?>
					</ul><?php endif; ?>
				</li><?php endforeach; ?>
			</ul>
		</div>
		<div id="content">