<?php
 	include("fckeditor/fckeditor.php");
 	
 	echo form::open('page/edit', array(), array('id' => $page->id, 'old_filename' => $page->filename)); ?>

 	<h3>Page Title:</h3>
 	<?=form::input(array('name' => 'title', 'value' => $page->title, 'class' => 'edit_page', 'id' => 'title'))?>
 	
 	<h3>Page Name:</h3>
 	<?=form::input(array('name' => 'page_name', 'value' => $page->page_name, 'class' => 'edit_page', 'id' => 'page_name'))?>
 	
 	<h3>Filename:</h3>
 	<?=form::input(array('name' => 'filename', 'value' => $page->filename, 'class' => 'edit_page', 'id' => 'filename'))?> <img src="/images/blank.png" id="filename_status" /> <span id="filename_text"></span>
 	
 	<h3>Organize Under:</h3>
 	<?=form::dropdown('child_of', $pages, $page->child_of)?>
 	
 	<h3>Place On Menu:</h3>
 	<?=form::checkbox('menu', TRUE, $page->menu)?>
 	
 	<hr />
 	
 	<?php $oFCKeditor = new FCKeditor('content') ;
	$oFCKeditor->BasePath = '/fckeditor/';
	$oFCKeditor->Value = $page->content;
	$oFCKeditor->Width  = '550' ;
	$oFCKeditor->Height = '500' ;
	$oFCKeditor->Create();
?>
<input type="submit" value="Submit Changes" id="edit_submit" />
</form>