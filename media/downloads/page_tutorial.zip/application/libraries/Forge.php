<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Rick Ellis
 * @copyright	Copyright (c) 2006-2007, pMachine, Inc.
 * @license		http://www.codeignitor.com/user_guide/license.html
 * @link		http://www.codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * Code Igniter FORm GEneration Class (Forge)
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Forms
 * @author		Woody Gilk
 * @credit		Andrew Champion, Amir, Joseph Crawford, and Jim Dalton for testing, finding bugs, and suggesting improvements
 * @link		http://wgilk.com/forge/
 * @license		http://creativecommons.org/licenses/by-sa/3.0/
 */

class Forge_Core {
	
	static  $tabindex;
	
	protected $action;
	protected $form_name;
	protected $form_id;
	protected $group_name;
	protected $last_group;
	protected $template;
	protected $rules;
	protected $table;
	protected $groups;
	protected $uploads;
	protected $errors;
	protected $group_errors;
	protected $elements;
	protected $attributes;
	protected $validated;
	protected $has_error;
	protected $has_upload;
	protected $label_before;
	protected $label_class;
	protected $use_buttons;
	
public function __construct ($params = array()) {
		// Load the necessary stuff
		$this->assign_libs  ('uri', 'load');
		$this->load->helper (array('url', 'form'));
		include_once('application/helpers/security_helper.php');
		include_once('application/helpers/inflector_helper.php');
		include_once('application/helpers/forge_helper.php');
		include_once('application/helpers/string_helper.php');
		// Let's go!
		$this->initialize($params);
		$this->tabindex = 1;
		// Why not...
		Log::add('debug', "Forge Class Initialized");
	}
	
	public function initialize ($params = array()) {
		// Reset defaults
		$this->action       = '';
		$this->form_name    = '';
		$this->form_id      = '';
		$this->template     = '';
		$this->upload_path  = '';
		$this->max_size     = '';
		$this->rules        = array();
		$this->upload_rules = array();
		$this->errors       = array();
		$this->group_errors = false;
		$this->label_before = true;
		$this->label_class  = false;
		$this->use_buttons  = false;
		
		// Set params
		if (count ($params) > 0) {
			foreach ($params as $param => $value)
				if (isset($this->$param)) $this->$param = $value;
		}
		
		// We can't allow the following variables to be set by the user
		$this->group_name = '[default]';
		$this->last_group = '[default]';
		$this->validated  = false;
		$this->has_error  = false;
		$this->has_upload = false;
		$this->tree       = array();
		$this->uploads    = array();
		$this->elements   = array();
		$this->attributes = array (
			'type', 'maxlength', 'value', 'options',
			'rows', 'cols', 'size',
			'selected', 'checked', 'disabled',
			'label', 'id', 'style',
			'before', 'after', 'extra', 'js');
		$this->label_before = (bool) $this->label_before;
		
		// Make sure action is set
		if ($this->action == false) $this->set_action();
		// Check upload path
		if ($this->upload_path != false) $this->set_upload_path ($this->upload_path);
		// Max size must be set
		if ($this->max_size == false) {
			// Cache the size
			static $size;
			// Fetch the size, if not cached
			if ($size == false) {
				// Use php.ini to set the size
				$size = @ini_get ('upload_max_filesize');
				// Check if the last character of the string is a number
				$byte = strtolower (substr ($size, -1, 1));
				if (! is_numeric ($byte)) {
					$size = substr ($size, 0, (strlen($size)-1));
					switch ($byte) {
						case 'g': $size *= 1024; // to MB
						case 'm': $size *= 1024; // to KB
						default: break; // Done
					}
				}
				else // The size in php.ini is set in bytes, we need kilobytes
					$size /= 1024;
			}
			// Set maximum size
			$this->max_size = $size;
		}
		// Create our default group
		$this->new_group ('default');
		$this->groups['default']['legend'] = $this->form_name;
	}
	
	public function debug ($var) {
		if (! isset($this->$var)) return;
		// Wee, it's sexy!
		return '<pre>'.var_export ($this->$var).'</pre>';
	}
	
	public function form_name ($name = false) {
		if ($name == false) $name = $this->form_name;
		return $name;
	}
	
	public function form_open ($data = false) {
		if ($data == false) $data = array();
		if ($this->form_id !== false) $data['id'] = $this->form_id;
		
		$form_open = $this->has_upload ? 'open_multipart' : 'open';
		
		return form::$form_open ($this->action, $data);
	}
	
	public function form_close() {
		return form::close();
	}
	
	public function has_errors() {
		return (($this->validated) ? (bool) $this->has_error : false);
	}
	
	// INPUT CREATION ---------------------------------------------------------
	
	public function set_action ($action = false) {
		if ($action == false) {
			if ($this->action != false) return false;
			$action = $this->uri->string();
		}
		
		$this->action = $action;
		return true;
	}
	
	public function set_upload_path ($path) {
		// Make sure the upload path is writable
		if (! is_writable ($path))
			throw new Kohana_Exception('forge.not_writable', $path);
		
		$this->upload_path = $path;
		return true;
	}
	
	public function new_group ($name, $legend = false, $cols = false) {
		// If name is false, we can't continue
		if ($name == false) return false;
		// Create index array
		$index = explode ('-', $name);
		if ($name != 'default') array_unshift ($index, 'default');
		// Compile index location
		$index = "['". implode ("']['", $index) ."']";
		// Save last group
		$this->last_group = $this->group_name;
		$this->groups[$name]['legend'] = $legend;
		$this->groups[$name]['type']   = 'list';
		if (is_array ($cols)) {
			// This is a table type
			$this->groups[$name]['type'] = 'table';
			// Check each column for valid data and add it
			foreach ($cols as $_name => $_data) {
				$this->filter_data ($_name, $_data);
				$this->groups[$name]['cols'][$_name] = $_data;
			}
		}
		
		return $this->switch_group ($index);
	}
	
	public function disable_group ($name) {
		// Don't remove the default group
		if ($name == false || $name == 'default') return false;
		// Don't remove a non-existent group
		if (! isset($this->groups[$name])) return false;
		// If we are in the group, get out
		if ($this->group_name == "[$name]") $this->prev_group();
		if ($this->last_group == "[$name]") $this->last_group = '[default]';
		// Remove the group
		unset ($this->groups[$name]);
		$this->tree_remove ($name, $this->tree, true);
		
		return true;
	}
	
	public function prev_group() {
		$index  = $this->last_group;
		// Save the last group, if not default
		if ($index != '[default]') {
			$offset = strrpos ($index, '[');
			$this->last_group = substr ($index, 0, $offset);
		}
		
		return $this->switch_group ($index);
	}
	
	public function set_group_text ($name, $text) {
		if (! isset($this->groups[$name])) return;
		// Set it!
		if ($text != false) $this->groups[$name]['text'] = trim($text);
	}
	
	public function get ($name, $key = false) {
		// No element by that name
		if (! isset($this->elements[$name]))
			$value = false;
		// No key requested, return the whole element
		elseif ($key == false)
			$value = $this->elements[$name];
		else {
			// Key found, return value
			if (isset($this->elements[$name][$key]))
				$value = $this->elements[$name][$key];
		}
		return (isset($value) ? $value : false);
	}
	
	public function set ($name, $key, $value = false) {
		if (! isset ($this->elements[$name])) return false;
		$this->elements[$name][$key] = $value;
		return true;
	}
	
	public function add ($name, $type = false, $data = false) {
		if ($name == false) return false;
		// This allows $type to be used as $data, when $data is false
		if (is_array($type) && $data == false)
			$data = $type;
		elseif (is_string($type) && is_array($data))
			$data['type'] = $type;
		// Filter our data
		$this->filter_data ($name, $data);
		// Add the input to the current group
		$this->group[]         = $name;
		$this->elements[$name] = $data;
		// Set upload status
		if ($data['type'] == 'file') $this->has_upload = true;
		// Set "checked" for checkboxes
		if ($data['type'] == 'checkbox') {
			// The "checked" attribute can be defined many ways
			$checked = array_remove('checked', $data);
			$this->set_checked($name, $checked);
			// We need a value for checkboxes, or stuff will break
			if (! isset($data['value'])) $data['value'] = '1';
		}
		
		return true;
	}
	
	public function remove ($name) {
		if ($name == false) return false;
		// Unset known variables
		unset (
			$this->elements[$name],
			$this->rules[$name],
			$this->upload_rules[$name]);
		// Remove it from the tree
		$this->tree_remove ($name, $this->tree);
		
		return true;
	}
	
	public function add_error ($name, $error) {
		if (! isset($this->elements[$name])) return false;
		// Get current errors
		$this->set_unset($this->elements[$name], 'error');
		// Set new error
		$this->elements[$name]['error'] .= sprintf('<p class="error">%s</p>%s', $error, "\n");
		
		return true;
	}
	
	public function add_rule($name, $rule) {
		if ($name == false) return false;
		if ($rule == false) return false;
		// Recursive ftw!
		if (is_array($rule)) {
			$rules = $rule;
			foreach ($rules as $rule)
				$this->add_rule($name, $rule);
			// Stop processing
			return true;
		}
		// Parse the rule
		$rule = $this->parse_rule($rule);
		if (is_array($rule))
			$this->upload_rules[$name] = implode('|', $rule);
		else {
			$this->set_unset($this->rules, $name);
			$pipe = (strlen($this->rules[$name]) > 0) ? '|' : '';
			$this->rules[$name] .= $pipe.$rule;
		}
		
		return true;
	}
	
	public function build ($template = false, $data = false) {
		if ($data == false) $data = array();
		
		// Data used for every type
		$data['name']   = $this->form_name();
		$data['open']   = $this->form_open();
		$data['close']  = $this->form_close();
		$data['tree']   = $this->tree;
		$data['groups'] = $this->groups;
		
		foreach ($this->elements as $name => $elem) {
			$type = array_remove ('type', $elem);
			$data['elements'][$name] = $this->input ($type, $name, $elem);
		}
		
		// Return array of elements
		if ($template === true) return $data;
		// Build with no template
		if ($template == false) {
			
			ob_start();
				print $data['open']."\n";
				$this->build_fieldset($data['tree'], $data['elements'], $data['groups'], true);
				print $data['close']."\n";
				$output = ob_get_contents();
			ob_end_clean();
			
			return $output;
		}
		return $this->load->view("forge/$template", $data)->render(FALSE);
	}
	
	public function label ($name, $id, $label) {
		// If the name is false, it would return an invalid label
		if ($name == false) return '';
		// Compile label
		$label = ($label == false) ? humanize ($name) : ucfirst ($label);
		// Add label class or <em>*</em> if the input is required
		$class = '';
		if ($this->is_required($name)) {
			if ($class = $this->label_class)
				$class = sprintf(' class="%s"', $class);
			else
				$label .= '<em>*</em>';
		}
		// Return a label
		return sprintf ('<label for="%s"%s>%s</label>', $id, $class, $label);;
	}
	
	public function input ($type, $name, $data) {
		// Need a valid name
		if ($name == false) return false;
		$data['name'] = $name;
		// The name for the label must not be an array type
		$_name = preg_replace ('@\[.*\]@', '', $name);
		// Create an id if it doesn't exist
		if (! isset($data['id'])) $data['id'] = "$type-$_name";
		// Get a label
		$label = (isset($data['label'])) ? array_remove ('label', $data) : humanize($_name);
		$nolabel = false;
		// Remove error if it exists
		$error = array_remove ('error', $data);
		// Remove before and after strings
		$before = array_remove ('before', $data);
		$after  = array_remove ('after',  $data);
		// Remove extra stuff
		$extra = array_remove('extra', $data);
		// Add scripts to data
		if ($script = array_remove('js', $data)) {
			$script = parse_form_attributes($script, array());
			$extra  = ($extra == '') ? $script : "$extra $script";
		}
		// Add tabindex to extra
		$extra = sprintf('tabindex="%s" %s', $this->tabindex++, $extra);
		// Create the input, using CI form_helper
		switch ($type) {
			case 'tablerow':
				$table = array_remove ('cols', $data);
				// This defines our inputs, so we need it
				if (! isset ($this->groups[$table]['cols']))
					show_error ("FORGE: Tablerow type inputs required the <tt>cols</tt> attribute to be set.");
				// Fetch input data
				$inputs = $this->groups[$table]['cols'];
				// Remove label column
				array_shift ($inputs);
				// Loop through inputs and build
				$n = 1;
				foreach ($inputs as $_key => $_data) {
					unset ($_data['label']);
					$_data['id'] = $name.$n++;
					$_type = array_remove ('type', $_data);
					$_name = sprintf ('%s[%s]', $name, $_key);
					if ($_data['type'] == 'dropdown')
						$_data['selected'] = $data['selected'][$_key];
					else
						$_data['value'] = $data['value'][$_key];
					$input[$_key] = array_remove ('input', $this->input ($_type, $_name, $_data));
				}
			break;
			case 'telephone':
				$value = array_remove ('value', $data);
				$input = $this->telephone ($name, $value);
			break;
			case 'citystatezip':
				$value = array_remove ('value', $data);
				$input = $this->citystatezip ($name, $value);
			break;
			case 'dateselect':
				$value = array_remove ('value', $data);
				$input = $this->dateselect ($name, $value);
			break;
			case 'dropdown':
				$options  = array_remove ('options', $data);
				$options  = is_array ($options) ? $options : array();
				$selected = array_remove ('selected', $data);
				if ($selected === false && $value = array_remove('value', $data))
					$selected = $value;
				$input = form::dropdown ($name, $options, $selected, $extra);
			break;
			case 'radio':
				$options  = array_remove ('options', $data);
				$options  = is_array ($options) ? $options : array();
				$selected = array_remove ('selected', $data);
				// Loop through elements and make radios
				$input = ''; $n = 1;
				foreach ($options as $opt => $title) {
					$_data = array(
						'name'    => $name,
						'id'      => 'radio-'.$name.$n++,
						'value'   => $opt,
						'checked' => ($opt == $selected) ? true : false);
					$_input = form::radio ($_data, '', true, $extra);
					$_label = $this->label($name, $_data['id'], $title)."\n";
					$input .= ($this->label_before) ? $_label.$_input : $_input.$_label;
				}
				$nolabel = true;
			break;
			case 'checkbox':
				$checked = array_remove('checked', $data);
				$input = form::checkbox ($data, '', $checked, $extra);
			break;
			case 'submit':
				$extra = $extra.' id="'.array_remove('id', $data).'"';
				$value = array_remove ('value', $data);
				$input = form::submit ($name, $value, $extra);
				// Enable <button> submits, instead of <input>
				if ($this->use_buttons == true) {
					$input = str_replace(
						array('<input', ' />'), 
						array('<button', '>'),
						$input);
					$input = str_replace('>', ">$value</button>", $input);
				}
			break;
			case 'hidden':
				$value = array_remove ('value', $data);
				$input = form::hidden ($name, $value);
			break;
			case 'text':
				$data['size'] = isset ($data['size']) ? $data['size'] : 20;
				$input = form::input ($data, '', $extra);
			break;
			case 'password':
				$data['size'] = isset ($data['size']) ? $data['size'] : 20;
				$input = form::password ($data, '', $extra);
			break;
			case 'file':
				unset ($data['value']);
				$this->has_upload = true;
				$data['size'] = isset ($data['size']) ? $data['size'] : 20;
				$input = form::upload ($data, '', $extra);
			break;
			default:
				$func = $type;
				// Bad input type request
				if (! method_exists ('form', $func))
					show_error ("FORGE: Invalid form input type <tt>\"$type\"</tt> requested for $name.");
				$input = form::$func ($data, '', $extra);
			break;
		}
		
		// The form helper adds a newline, we don't want it
		if (!is_array ($input)) $input = trim($input);
		// Create a label
		$label = ($nolabel == false && $type != 'hidden' && $type != 'submit')
		       ? $this->label($name, $data['id'], $label) : '';
		// Add error if one exists
		if ($this->validated && $this->group_errors == false) {
			$e = "{$name}_error";
			$e = (isset ($this->validation->$e)) ? $this->validation->$e : '';
			$error = "$error\n$e";
		}
		
		// Compile our return
		$return['error'] = $error;
		$return['label'] = $label;
		$return['input'] = (is_array($input)) ? $input : $before.$input.$after;
		
		return $return;
	}
	
	// VALIDATION AND POST RETREVAL FUNCTIONS ---------------------------------
	
	public function validate() {
		// We have validated!
		$this->validated = true;
		// Validate uploads
		$this->validate_uploads();
		// No need to validate if there are no rules
		if (count ($this->rules) < 1) return true;
		// Import the rules
		$rules = $this->rules;
		// Set the fields
		foreach (array_keys ($rules) as $e) {
			$field = (isset ($this->elements[$e]['label'])) ? $this->elements[$e]['label'] : humanize ($e);
			$fields[$e] = strtolower ($field);
		}
		// Load Validation library
		$this->load->library ('validation');
		$this->assign_libs   ('validation');
		$this->validation->error_format = '<p>%s</p>';
		$this->validation->set_rules  ($rules);
				
		// Run validation
		$return = $this->validation->run();
		// Set error state
		if ($return == false) $this->has_error = true;
		
		// @credit: Thanks to Amir for this fix
		// Return true only if validation was sucessful, and we do not have an error
		return ($return & ! $this->has_error);
	}
	
	public function validate_uploads() {
		// No rules, no reason to continue
		if (count ($this->upload_rules) < 1) return true;
		// We default to DOCROOT/upload for uploading files
		if ($this->upload_path == false) $this->set_upload_path ('./upload/');
		// Load Upload class
		$this->load->library ('upload');
		$this->assign_libs   ('upload');
		// Default configuration
		$conf['max_size']      = $this->max_size;
		$conf['upload_path']   = $this->upload_path;
		$conf['allowed_types'] = '';
		$conf['xss_clean']     = false;
		$conf['remove_space']  = true;
		// Run all uploads
		$uploads = array();
		foreach ($this->upload_rules as $name => $allow) {
			$conf['allowed_types'] = $allow;
			$this->upload->initialize ($conf);
			if ($this->upload->do_upload ($name))
				// Set uploaded file data
				$this->uploads[$name] = $this->upload->data();
			// If $_FILES[$name] is set, but the upload failed, it means that
			// the upload is an invalid type, and we need to display that error
			/*elseif ($this->is_required ($name) || @$_FILES[$name]['name']) {
				// Yes, we have an error
				$this->has_error = true;
				// Fetch the error report
				$error = $this->upload->display_errors ('<p class="error">', '</p>');
				$this->elements[$name]['error'] = $error;
				// No valid upload data
				$this->uploads[$name] = false;
			}*/
			// Unset validation rules, because only 'allowed' and 'required'
			// are valid file input rules, and we just tested both rules
			unset ($this->rules[$name], $error);
		}
		
		return ( ! $this->has_error);
	}
	
	public function populate ($return = false) {
		if (count($_POST) < 1)
			return (($return == FALSE) ? FALSE : array());
		
		$this->assign_libs ('input');
		$values = array();
		
		foreach (array_keys($this->elements) as $name) {
			// The key we will set
			$key = 'value';
			// Retrieve value for this input
			if ($this->validated) {
				if (preg_match('@^([\w].+)\[([\w\n _,].+)\]$@', $name, $_name)) {
					// Get the value
					$value = $this->input->post ($_name[1]);
					$value = $value[$_name[2]];
					// Clean up
					unset($_name);
				}
				else $value = $this->input->post ($name);
			}
			elseif ($this->elements[$name]['type'] == 'dropdown')
				$value = $this->elements[$name]['selected'];
			else
				$value = $this->elements[$name]['value'];
			// Some elements require a different key to be set
			switch ($this->elements[$name]['type']) {
				// This one is strange because we have to return the value of checkbox,
				// but set the "checked" status checking the POST against the set value
				case 'checkbox':
					$retval = $this->elements[$name]['value'];
					// Set checked only if the POST is the same as value
					if ($this->validated)
						$this->elements[$name]['checked'] = ($value == $retval) ? true : false;
					// We must always set value back to the original value
					$value = $retval;
					// If the element is not checked, we return false
					$retval = ($this->elements[$name]['checked'] == true) ? $retval : false;
				break;
				case 'dropdown': $key = 'selected'; break;
				case 'radio':    $key = 'selected'; break;
				case 'submit': $value = $this->elements[$name]['value']; break;
				case 'file':  if (isset($this->uploads[$name])) $retval = @$this->uploads[$name]; break;
			}
			// If specific return is set, use $value
			if (! isset ($retval)) $retval = $value;
			// Set the value of this input
			$this->elements[$name][$key] = $value;
			$values[$name] = $retval;
			// Don't leave garbage around
			unset($retval);
		}
		
		return (((bool) $return) ? $values : true);
	}
	
	public function post_data ($print = false) {
		// Run validation if it hasn't already
		if ($this->validated == false) $this->validate();
		// Fetch POST data
		$post = $this->populate (true);
		// Print request outputs the POST data
		if ($print == true) {
			$pre = '';
			foreach ($post as $key => $val)
				$pre .= sprintf ("%20s: %s \n", $key, print_r($val,true));
			
			return sprintf ("<h6>POST DATA (debug)</h6>\n<pre>\n%s</pre>\n", $pre);
		}
		// If validation causes an error, return nothing
		if ($this->has_error == true) return false;
		
		return $this->populate (true);
	}
	
	// XML FORM PARSING FUNCTIONS ---------------------------------------------
	
	public function load ($name) {
		// We can't load XML via load_class, because it prefixes it with CI_
		$obj =& get_instance();
		$obj->load->library ('xml');
		// Load the form
		if (! $obj->xml->load ("forms/$name"))
			show_error ("FORGE: Requested form does not exist: $name.");
		// Parse the XML into an array
		$data = $obj->xml->parse();
		if (! is_array($data)) 
			show_error ("FORGE: Requested form could not be parsed: $name.");
		// Get data
		$data = $data['form'][0];
		// Set up our configuration
		$conf['action']    = $data['__attrs']['action'];
		$conf['form_name'] = $data['fieldset'][0]['__attrs']['name'];
		// Initialize our shiny form
		$this->initialize ($conf);
		// Build the tree, extract inputs
		$this->get_fields ($data['fieldset'][0]);
		
		return true;
	}
	
	protected function get_fields ($array) {
		foreach ($array as $name => $val) {
			if ($name == 'fieldset') {
				// Add fieldsets into the tree
				foreach ($val as $set) {
					// Get a name and a legend for recursion
					$legend = ucfirst ($set['__attrs']['name']);
					$text   = @$set['__attrs']['text'];
					$name   = url_title ($legend, 'underscore');
					// Create new fieldset and build it
					$this->new_group  ($name, $legend);
					$this->set_group_text ($name, $text);
					$this->get_fields ($set);
					// Switch to previous fieldset
					$this->prev_group();
				}
			} elseif (! is_numeric ($name) && $name != '__attrs') {
				// Add inputs
				foreach ($val as $data) {
					if (! is_array ($data)) continue;
					// Parse attributes
					if ($attrs = array_remove ('__attrs', $data)) {
						$rules = array_remove ('rules', $attrs);
						$allow = array_remove ('allow', $attrs);
						// Add allowed file types into rules
						if ($allow != false) {
							$pipe  = (strlen ($rules) > 1) ? '|' : '';
							$allow = str_replace ('|', ',', $allow);
							$rules = "{$rules}{$pipe}allow[{$allow}]";
						}
						// Have to use an zero index because of next fix
						if ($rules != false) $data['rules'][0] = $rules;
					}
					// Fix indexing
					foreach ($data as $k => $v) {
						$val = $v[0];
						// Options need to be to shifted
						if ($k == 'options') $val = array_map('array_shift', $val);
						$data[$k] = $val;
					}
					// Add the input
					if (! isset($data['label'])) $data['label'] = $name;
					$this->add ($name, $data);
				}
			}
		}
	}
	
	// LEGACY ALIASES
	
	public function disable ($name) { return $this->remove($name); }
	
	// protected HELPER FUNCTIONS -----------------------------------------------
	
	protected function assign_libs() {
		static $loaded;
		
		$libs = func_get_args();
		if (count ($libs) > 0) {
			$obj =& Kohana::instance();
			foreach ($libs as $lib) {
				if (isset ($loaded[$lib])) continue;
				if (isset ($obj->$lib) && is_object($obj->$lib)) {
					$this->$lib =& $obj->$lib;
					$loaded[$lib] = true;
				}
			}
		}
	}
	
	protected function filter_data ($name, &$data) {
		if (! is_array($data)) $data = array();
		if (! isset($data['type'])) $data['type'] = 'text';
		// Set rules
		if ($rules = array_remove ('rules', $data)) {
			if (! is_array($rules)) $rules = explode('|', $rules);
			foreach ($rules as $rule) 
				$this->add_rule($name, $rule);
		}
		// Filter data
		$filter = array();
		foreach ($this->attributes as $a) 
			if (isset ($data[$a])) $filter[$a] = $data[$a];
		// Make sure "checked" var is set for checkboxes
		if ($data['type'] == 'checkbox')
			if (! isset($data['checked'])) $data['checked'] = false;
		// Convert data to filtered
		$data = $filter;
	}
	
	protected function parse_rule($rule) {
		// No array data in rule, no parsing necessary
		if (($end = strpos($rule, '[')) === false)
			return $rule;
		
		$_rule = substr($rule, 0, $end);
		switch($_rule) {
			case 'required':
				if ($size = strtoarray ($rule)) {
					// Make min an integer
					$min = (int) $size[0];
					// Max is an integer if the format was [2,3], otherwise false
					$max = (isset ($size[1])) ? (int) $size[1] : false;
					// No max and a min means exact length
					if ($max === false && $min > 0)
						$_rule .= "|exact_length[$min]";
					// If min and max are the same, exact length
					elseif (($min == $max) && $min > 0)
						$_rule .= "|exact_length[$min]";
					// Min and max are not both zero
					else {
						if ($min > 0)    $_rule .= "|min_length[$min]";
						if ($max > $min) $_rule .= "|max_length[$max]"; 
					}
				}
			break;
			case 'allow':
				$_rule = strtoarray($rule);
			break;
			default:
				$_rule = $rule;
			break;
		}
		
		return $_rule;
	}
	
	protected function is_required ($name) {
		// No rules? Not required.
		if (! isset ($this->rules[$name])) return false;
		// Check if required
		return ((strpos ($this->rules[$name], 'required') !== false) ? true : false);
	}
	
	protected function set_unset(&$array) {
		if (! is_array($array)) return;
		$args = func_get_args();
		array_shift($args); // Remove &$array
		
		$sub =& $array;
		while ($key = array_shift($args)) {
			if (! isset($sub[$key])) $sub[$key] = null;
			// Nasty hacks FTW!
			$tmp =& $sub[$key]; unset($sub);
			$sub =& $tmp;       unset($tmp);
		}
	}
	
	protected function set_checked($name, $checked) {
		if (! isset($this->elements[$name])) return false;
		if ($this->elements[$name]['type'] != 'checkbox') return false;
		// No need to convert to boolean if it already is boolean
		if ($checked !== true && $checked !== false)
			$checked = in_array($checked, array('1', 'true', 'checked'), true) ? true : false;
		// Set status
		$this->elements[$name]['checked'] = $checked;
	}
	
	protected function switch_group ($index) {
		if ($index == false) return;
		// Compile selection
		$switch = '$this->group =& $this->tree'.$index.';';
		// Unset current group
		unset ($this->group);
		// Make our switch
		@eval($switch);
		// Save group name
		$this->group_name = $index;
	}
	
	protected function tree_remove ($name, &$array, $group = false) {
		foreach ($array as $key => $val) {
			// Recursive FTW!
			if (is_array ($val)) {
				// For group removal
				if ($group == true && $key === $name) {
					unset($array[$key]);
					return;
				}
				// Normal removal
				$this->tree_remove ($name, $array[$key], $group);
				// No elements means we can remove the group
				if (count ($array[$key]) < 1) unset ($array[$key], $this->tree[$key]);
				continue;
			}
			// Kill it!
			if ($val == $name) unset ($array[$key]);
		}
	}
	
	protected function build_fieldset ($set, $elements, $groups, $first = false) {
		// Recursive for the win!
		foreach ($set as $g => $e) {
			if (is_array ($e)) {
				// Do not build empty groups
				if (count($e) < 1) continue;
				// Start row
				if ($first == false) printf ('<li>%s', "\n");
				// Add errors to top, if group_errors is enabled
				if ($first == true && $this->group_errors && $this->validated && $errors = $this->validation->error_string)
					printf ('<div class="errors">%s%s</div>%s', "\n", $errors, "\n");
				// Start form
				printf ('<fieldset class="%s"><legend>%s</legend>%s', $g, $groups[$g]['legend'], "\n");
				if (isset($groups[$g]['text'])) printf ('<p>%s</p>%s', $groups[$g]['text'], "\n");
			}
			// Build tables
			if (isset($groups[$g]) && $groups[$g]['type'] == 'table') {
				$table = array();
				foreach ($groups[$g]['cols'] as $group) $cols[] = $group['label'];
				$table[] = $cols;
				foreach ($e as $_e) {
					$t = array();
					$row = $elements[$_e];
					$t[] = $row['label'];
					foreach ($row['input'] as $col) $t[] = $col;
					$table[] = $t;
				}
				// Add table to row
				printf ('%s%s', $this->table->generate($table), "\n");
			} else {
				// New group
				if (is_array ($e)) {
					printf ('<ol class="layout">%s', "\n");
					$this->build_fieldset ($e, $elements, $groups);
					printf ('</ol>%s', "\n");
				} else {
					$label = $elements[$e]['label'];
					$input = $elements[$e]['input'];
					$error = $elements[$e]['error'];
					// Add input to the row
					if (strpos ($input, 'type="hidden"') === false) {
						if ($label != false) $label = ($this->label_before) ? "$label\n" : "\n$label";
						$middle = ($this->label_before) ? $label.$input : $input.$label;
						$middle = "\n$middle$error\n";
						printf ('<li class="row%s">%s</li>%s', alternator('', ' alt'), $middle, "\n");
					}
					// Add hidden inputs
					else printf ('%s%s', $input, "\n");
				}
			}
			// Close group
			if (is_array ($e)) {
				printf ('</fieldset>%s', "\n");
				if ($first == false) printf ('</li>%s', "\n");
			}
		}
	}
	
	// META FUNCTIONS ---------------------------------------------------------
	
	public function citystatezip ($name = false, $data = false, $label = false) {
		// These variables will need to be defined
		$required = array ('city', 'state', 'zip', 'plus4');
		foreach ($required as $req)
			if (! isset ($data[$req])) $data[$req] = '';
		
		// Sanity checks
		$name = ($name  == false) ? 'location' : $name;
		// Create a label
		if ($label !== false) $label = $this->label ($name, $name, $label);
		// Set the basename of the input
		$bname = "{$name}[%s]";
		
		extract ($data, EXTR_OVERWRITE);
		list ($zip, $plus4) = explode ('-', valid_zip ($zip, (bool)$plus4));
		
		// Create City input
		$input = array();
		$input['size']  = 20;
		$input['value'] = valid_city ($city);
		$input['label'] = ($label == false) ? 'City/State/Zip' : $label;
		$city = $this->input ('text', sprintf($bname, 'city'), $input);
		
		// Create State dropdown
		$input = array();
		$state = valid_state ($state);
		$input['options']  = array_keys (valid_states());
		$input['options']  = array_combine ($input['options'], $input['options']);
		$input['selected'] = valid_state ($state);
		$state = $this->input ('dropdown', sprintf($bname, 'state'), $input);
		
		// Create ZIP code input
		$input = array();
		$input['size']  = 5;
		$input['value'] = $zip;
		$input['maxlength'] = 5;
		$zip = $this->input ('text', sprintf($bname, 'zip'), $input);
		
		// Create plus4 input and append it to the zip input
		if ($zip != false && $plus4 != false) {
			$input = array();
			$input['size'] = 4;
			$input['value'] = $plus4;
			$input['maxlength'] = 4;
			$plus4 = $this->input ('text', sprintf($bname, 'plus4'), $input);
			$plus4 = $plus4['input'];
			$zip['input'] .= "-$plus4";
		}
		
		// Compile our label and input
		$return = $city['input'].' '.$state['input'].' '.$zip['input'];
		if ($label != false) {
			$r['label'] = $city['label'];
			$r['input'] = $return;
			$return = $r;
		}
		
		return $return;
	}
	
	public function telephone ($name = false, $number = false, $label = false) {
		// Sanity checks
		$name   = ($name  == false) ? 'telephone'    : $name;
		$number = ($number == true) ? valid_phone ($number, '-') : '--';
		// Create the label
		if ($label !== false) $label = $this->label ($name, $name, $label);
		// Set our basename for the inputs
		$bname = "{$name}[%s]";
		
		// Extract the area code, prefix, and digits
		list ($area, $prefix, $digits) = explode ('-', $number);
		
		// Create the area, prefix, and digit inputs
		$inputs = array('area' => 3, 'prefix' => 3, 'digits' => 4);
		foreach ($inputs as $name => $size) {
			$input['size']  = $size;
			$input['value'] = $$name;
			$input['maxlength'] = $size;
			// We only want the input part
			$$name = array_remove ('input', $this->input ('text', sprintf ($bname, $name), $input));
		}
		
		// Compile a label and input
		$return = "($area) $prefix-$digits";
		if ($label != false) {
			$r['label'] = $label;
			$r['input'] = $return;
			$return = $r;
		}
		
		return $return;
	}
	
	public function dateselect ($name = false, $data = false, $label = false) {
		// These variables will need to be defined
		$required = array ('month', 'day', 'year', 'hour', 'minute');
		foreach ($required as $req)
			if (! isset ($data[$req])) $data[$req] = '';
		
		// Sanity checks
		$name = ($name  == false) ? 'yearmonthday' : $name;
		// Create a label
		if ($label !== false) $label = $this->label ($name, $name, $label);
		// Set the basename of the input
		$bname = "{$name}[%s]";
		
		extract ($data, EXTR_OVERWRITE);
		// Valid month
		if ($month !== '') {
			$month = (int) substr($month, 0, 2);
			$month = ($month > 12 || $month < 1) ? 1 : $month;
		} 
		else $month = date('n'); // This month
		// Valid year
		if ($year !== '') {
			$year = (int) substr($year, 0, 4);
			// If the year is only two digits long, and greater than the current last two
			// digits of this year, we make the year 19XX, if not, 20XX
			$year = (strlen ($year) < 4) ? ((substr ($year, -2, 2) > date('y')) ? "19$year" : "20$year") : $year;
		}
		else $year = date('Y'); // This year
		// Valid day
		if ($day !== '') {
			$day = (int) substr($day, 0, 2);
			// If the day is greater than the possible number of days for $month,
			// we change the day to the maximum possible date for $month
			$max = date('t', mktime(1, 0, 0, $month, 1, $year));
			$day = ($day > $max) ? $max : $day;
		}
		else $day = date('j'); // This day
		// Create dropdown options
		// Months
		for ($i=1;$i<13;$i++) $months[$i] = date('m', mktime(1, 0, 0, $i, 1, $year));
		// Years
		for ($i=date('Y');$i>2006;$i--) $years[$i] = $i;
		// Days
		for ($i=1;$i<32;$i++) $days[$i] = $i;
		// Hours
		for ($i=0;$i<23;$i++) $hours[$i] = $i;
		// Minutes
		for ($i=0;$i<60;$i+=15) $minutes[$i] = $i;
		
		// Create month dropdown
		$input['options']  = $months;
		$input['selected'] = $month;
		$input['label'] = ($label == false) ? 'Month/Day/Year' : $label;
		$month = $this->input ('dropdown', sprintf($bname, 'month'), $input);
		$input = array();
		// Create day dropdown
		$input['options']  = $days;
		$input['selected'] = $day;
		$day = $this->input ('dropdown', sprintf($bname, 'day'), $input);
		// Create year dropdown
		$input['options']  = $years;
		$input['selected'] = $year;
		$year = $this->input ('dropdown', sprintf($bname, 'year'), $input);
		// Create hours dropdown
		$input['options']  = $hours;
		$hour = $this->input ('dropdown', sprintf($bname, 'hour'), $input);
		// Create minutes dropdown
		$input['options']  = $minutes;
		$minute = $this->input ('dropdown', sprintf($bname, 'minute'), $input);
		// Compile our label and input
		$return['input'] = $month['input'].' '.$day['input'].' '.$year['input'].'@'.$hour['input'].':'.$minute['input'];
		$return['label'] = $month['label'];
		// No label? Then just return the input
		if ($label == false) $return = $return['input'];
		
		return $return;
	}
	
	public function submit_cancel ($submit = false, $cancel = false) {
		$input = array();
		$input['value'] = ($submit == false) ? 'Submit' : $submit;
		$name = url_title ($submit, 'underscore');
		$submit = $this->input ('submit', $name, $input);
		
		$input = array();
		$input['value'] = ($cancel == false) ? 'Cancel' : $cancel;
		$name = url_title ($submit, 'underscore');
		$cancel = $this->input ('submit', $name, $input);
		
		return "$submit $cancel";
	}
	
}

if (! function_exists ('array_remove')) {
	function array_remove ($key, &$array) {
		// @variable: string $key
		// @variable: array &$array
		// @return: value of $array[$key]
		if (! is_array ($array))    return false;
		if (! isset ($array[$key])) return false;

		$return = $array[$key];
		unset ($array[$key]);

		return $return;
	}
}

if (! function_exists ('array_unshift_assoc')) {
	function array_unshift_assoc ($array, $key, $val = false) {
		$array = array_reverse ($array, true);
		$array[$key] = $val;
		$array = array_reverse ($array, true);
		// Return array
		return $array;
	} 
}

if (! function_exists ('strtoarray')) {
	function strtoarray ($string) {
		$return = false;
		// Matches a string "like[this]" or "maybe[7,h,1,5]"
		if (preg_match ('@(\w+)\[([\w\d,]+)\]@', $string, $matches)) {
			$vars = explode (',', $matches[2]);
			// Compile array
			while ($var = array_shift ($vars)) $array[] = $var;
			// Valid return
			$return = $array;
		}

		return $return;
	}
}

?>

