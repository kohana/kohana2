function addCommas(nStr)
{
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

$.fn.hoverClass = function(c) {
    return this.each(function(){
        $(this).hover( 
            function() { $(this).addClass(c); },
            function() { $(this).removeClass(c); }
        );
        
    });
};

$(document).ready(
	function() 
	{
		/* KEEP CODE FROM HERE DOWN TO NEXT COMMENT BLOCK ON ALL PROJECTS */
		
		$('input#filename').keyup(function()
		{
			jQuery.ajax(
		   	{
		   		type: "GET",
		   		url: "/page/check_filename.html?filename=" + $(this).val() + '&old_filename='+$('#old_filename').val(),
		   		dataType: "html",
		   		timeout: 15000,
		   		error: function() {},
		   		success: function(r) {
		   								if (r == 'success')
		   								{
		   									$("#filename_status").attr({src: '/images/icons/accept.png'}); 
		   									if ($('input#title').val() != '') 
		   										$("#edit_submit").attr('disabled', false);
		   									$("#filename_text").html('');
		   								}
		   								else
		   								{
		   									$("#filename_status").attr({src: '/images/icons/delete.png'}); 
		   									$("#filename_text").html(r);
		   									$("#edit_submit").attr('disabled', true);
		   								}
		   							}
		   	});
		});

		$('input#title').keyup(function()
		{
			if ($(this).val() != '')
			{
				$("#title_status").attr({src: '/images/icons/accept.png'}); 
				if ($("#filename_status").attr('src') == '/images/icons/accept.png')
					$("#edit_submit").attr('disabled', false);
		   	}
		   	else
		   	{
		   		$("#title_status").attr({src: '/images/icons/delete.png'}); 
		   		$("#edit_submit").attr('disabled', true);
		   	}
		});

		$('.confirm_anchor').click(function()
		{
			return confirm('Are you SURE you want to do this???');
		});
		
		
		/* KEEP CODE FROM HERE UP TO PREVIOUS COMMENT BLOCK ON ALL PROJECTS*/
		
		$("ul.nav li").hover(function(){ $("ul", this).fadeIn("fast"); }, function() { } );
		$("ul.nav li").hoverClass ("hover");

	}
);