<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Rick Ellis
 * @copyright	Copyright (c) 2006, pMachine, Inc.
 * @license		http://www.codeignitor.com/user_guide/license.html
 * @link		http://www.codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * Code Igniter Forger Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Forge
 * @author		Woody Gilk
 * @link		http://wgilk.com/code_igniter/libraries/Forge.html
 * @license		http://creativecommons.org/licenses/by-sa/3.0/
 */

// ------------------------------------------------------------------------


// Get a list of states, based on language
function valid_states() {
	static $states;
	// Set up states
	if (! is_array ($states)) {
		$obj =& get_instance();
		$obj->load->language ('forge');
		$states = $obj->lang->line ('states');
	}
	
	return $states;
}

// Validate a state
function valid_state ($state) {
	$states = valid_states();
	// State should be a 2 letter uppercase
	$state  = strtoupper (substr($state, 0, 2));
	// Check for valid state
	$state = (isset ($states[$state])) ? $state : false;
	
	return $state;
}

// Validate a zipcode
function valid_zip ($zip, $plus_four = false) {
	// Standard length is 5, plus4 is 9
	$length = ($plus_four == false) ? 5 : 9;
	// Remove all non-digits characters
	$zip = preg_replace ('@[^\d]+@', '', $zip);
	// Shorten $zip to $length
	$zip = substr ($zip, 0, $length);
	// Validate length
	if (strlen ($zip) < $length) return false;
	// Compile zipcode with plus4
	if ($plus_four == true) {
		$four = substr ($zip, -4, 4);
		$zip  = substr_replace ($zip, "-$four", 5, $length);
	}
	
	return $zip;
}

// Validate a city
function valid_city ($city) {
	return ucwords ($city);
}

// Validate a phone number
function valid_phone ($number, $sep = '-') {
	if (is_array ($number)) $number = implode ($sep, $number);
	// If $sep is false, it means the length will be shorter
	$length = ($sep == false) ? 10 : 12;
	// Replace all non-digit characters with $sep
	$number = preg_replace ('@[^\d]+@', $sep, $number);
	// Double check $length
	if (! strpos ($number, $sep)) $length -= 2;
	// We only want the last $length digits of the number
	// so that was don't get the '1' prefix, etc
	$number = substr ($number, -$length, $length);
	// If the length of $number is not equal to $length, we have a problem
	if (strlen ($number) !== $length) false;

	// Matches the format 123-456-7890
	$pattern = "@(\d{3})$sep?(\d{3})$sep?(\d{4})@";
	if (! preg_match ($pattern, $number, $matches)) return false;
	array_shift ($matches); // Removes the pattern

	// Create our validated number and return it
	$number = implode ($sep, $matches);
	return $number;
}

?>