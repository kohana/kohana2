<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'add' => 'An error occured adding the page. Please go back and check your input',
	'delete' => 'An error occured deleting the page. Please go back and check your input',
	'edit' => 'An error occured editing the page. Please go back and check your input'
);
