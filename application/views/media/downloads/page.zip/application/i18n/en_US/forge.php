<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'not_writable' => 'FORGE: The file upload path <tt>%s</tt> must be server writable.'
);
