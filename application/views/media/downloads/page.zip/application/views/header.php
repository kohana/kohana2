<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >
	<head>
		<title><?=$title?></title>
		<link rel="stylesheet" type="text/css" href="/css/layout.css" />
		<link rel="stylesheet" type="text/css" href="/css/style.css" />
		<link rel="stylesheet" type="text/css" href="/css/menu.css" />

		<script type="text/javascript" src="/js/jquery.js"></script>
		<script type="text/javascript" src="/js/jquery.livequery.js"></script>
		<script type="text/javascript" src="/js/jquery.corner.js"></script>
		<script type="text/javascript" src="/js/jquery.overlabel.js"></script>
		<script type="text/javascript" src="/js/jqModal.js"></script>
		<script type="text/javascript" src="/js/effects.js"></script>
	</head>
	<body>
		<div id="menu">
			<ul class="nav">
				<?php foreach ($menu["menu"] as $url => $title):?>
				<li><?=html::anchor($url, htmlentities($title))?>
					<?php if (isset($menu["submenu"][$url])):?><ul>
						<?php foreach ($menu["submenu"][$url] as $child_url => $title):?>
						<li><?=html::anchor($child_url, htmlentities($title))?></li>
						<?php endforeach; ?>
					</ul><?php endif; ?>
				</li><?php endforeach; ?>
			</ul>
		</div>
		<div id="content">