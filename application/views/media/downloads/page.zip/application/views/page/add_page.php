<?php
 
 	include("fckeditor/fckeditor.php");
 	
 	echo form::open('page/add_page', array(), array('old_filename' => '**********')); ?>
 	
 	<h3>Title:</h3>
 	<?=form::input(array('name' => 'title', 'class' => 'edit_page', 'id' => 'title'))?> <img src="/images/icons/delete.png" id="title_status" />
 	
 	<h3>Page Name:</h3>
 	<?=form::input(array('name' => 'page_name', 'class' => 'edit_page', 'id' => 'page_name'))?>
 	
 	<h3>Filename:</h3>
 	<?=form::input(array('name' => 'filename', 'class' => 'edit_page', 'id' => 'filename'))?> <img src="/images/icons/delete.png" id="filename_status" /> <span id="filename_text"></span>
 	
 	<h3>Organize Under:</h3>
 	<?=form::dropdown('child_of', $pages)?>
 	
 	<h3>Place On Menu:</h3>
 	<?=form::checkbox('menu', TRUE, FALSE)?>
 	
 	<h3>Order:</h3>
 	<?=form::input(array('name' => 'order', 'class' => 'edit_page', 'id' => 'order'))?>
 	
 	<hr />
 	
 	<?php $oFCKeditor = new FCKeditor('content') ;
	$oFCKeditor->BasePath = '/fckeditor/';
	$oFCKeditor->Value = "";
	$oFCKeditor->Width  = '550' ;
	$oFCKeditor->Height = '500' ;
	$oFCKeditor->Create();
	
?>
<input type="submit" value="Submit Changes" id="edit_submit" disabled="disabled" />
</form>