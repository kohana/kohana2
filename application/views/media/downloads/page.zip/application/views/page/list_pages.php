<?php foreach ($pages as $page):?>
	<h3><?=html::anchor("/" . strtolower(str_replace(" ", "_", $page[0]->filename)), $page[0]->title)?> | <?=html::anchor("/page/edit/" . $page[0]->filename, "Edit")?> | <?=html::anchor("/page/delete/".$page[0]->id, "Delete", array('class' => 'confirm_anchor'))?></h3>
	<blockquote><?php foreach ($page as $id => $item):?>
		<?php if ($id != "0"): ?>
		<h4><?=html::anchor("/" . $page[0]->filename . "/" . strtolower(str_replace(" ", "_", $item->filename)), $item->title)?> | <?=html::anchor("/page/edit/" . strtolower(str_replace(" ", "_", $item->filename)), "Edit")?> | <?=html::anchor("/page/delete/$item->id", "Delete", array('class' => 'confirm_anchor'))?></h4>
		<?php endif; ?>
	<?php endforeach; ?></blockquote>
<?php endforeach; ?>
<h3 style="margin-top: 25px;"><?=html::anchor('page/add_page', 'Add a new page')?></h3>