<?php
/*
 * IM0075_www.cnhassetnet.com - loginform.php - Created on Jun 28, 2006 9:50:01 AM 2006
 * By: Jeremy Bush
 * Image Management LLC
 */
?>
<h1>Log In</h1>
<?php if(isset($_SESSION['message'])):?><h2 style="color: red;"><?=$_SESSION['message']?></h2><?php endif; ?>
<?=form::open('user/login')?>
<table width="250" border="0" cellpadding="2" cellspacing="2" style="border:1px solid #c0c0c0;background:#F5F4EA;">
	<tr>
		<td width="30%"><label for="username">Username:</label></td>
		<td><?php echo form::input( array( 'name'=>'username', 'id'=>'username', 'class'=>'fw' ) ); ?></td>
	</tr>
	<tr>
		<td width="30%"><label for="password">Password:</label></td>
		<td><?php echo form::password( array( 'name'=>'password', 'id'=>'passwrd', 'class'=>'fw' ) ); ?></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><?php echo form::submit('submit', 'Login', 'class="button"'); ?></td>
	</tr>
</table>
<?php echo form::close(); ?>
