<?php
/*
 * Class: Page_Controller
 *  
 * Kohana Source Code:
 *  author    - Jeremy Bush
 *  copyright - (c) 2007 Jeremy Bush
 *  license   - <http://kohanaphp.com/license.html>
 *
 */
class Page_Controller extends Controller {

	var $header = '';
	var $content = '';
	var $footer = '';
	var $location = '';

	var $layout = '';

	function __construct()
	{
		parent::__construct();

		$this->load->model('page');
		$this->header = array('menu' => $this->page->get_menu(), 'title' => "radd-cpa.org :: Home");

		/* Get the page (page or folder/page) */
		$base = ($this->uri->segment(2) == 'edit') ? 2 : 0;

		if ($this->uri->segment((1+$base)) !== false && $this->uri->segment((2+$base)) !== false) // This is a sub page
			$this->location = array("parent" => $this->uri->segment((1+$base)), "child" => $this->uri->segment((2+$base)));
		else if ($this->uri->segment((1+$base)) !== false && $this->uri->segment((2+$base)) === false) // This is a main page
			$this->location = array("parent" => $this->uri->segment((1+$base)));
		else // This is the home page
			$this->location = array("parent" => "index");

		$this->layout = $this->load->view('layout');

		$this->layout->footer = ($this->input->get('no_header')) ? '' : $this->load->view('footer', array('menu' => $this->page->get_menu()));
	}

	function index()
	{
		if ($page = $this->page->get_page($this->location))
		{
			if (!$this->input->get('no_header'))
				$this->layout->header = $this->load->view('header', array_merge($this->header, array('title' => $page->title)));
			else
				$this->layout->header = '';
			$this->layout->content = $this->load->view('page/index', array('page' => $page));

			$this->layout->render(TRUE);
		}
		else
			Kohana::show_404();
	}

	function edit()
	{
		if (!$this->auth->check_logged_in())
			Kohana::show_404();
		
		if (!$this->input->post('title'))
		{
			if ($page = $this->page->get_page($this->location))
			{
				$menu_items = $this->page->get_menu_list();
				$this->layout->header = $this->load->view('header', array_merge($this->header, array('title' => $page->title)));
    			$this->layout->content = $this->load->view('page/edit', array('page' => $page, 'pages' => $menu_items));

    			$this->layout->render(TRUE);
			}
			else
				Kohana::show_404();
		}
		else
		{
			if ($this->page->edit_page($this->input->post()))
				url::redirect(str_replace(".html", "", $this->session->get('last_page')));
			else
				throw new Kohana_Exception('page.edit');
		}
	}

	function add_page()
	{
		if (!$this->auth->check_logged_in())
			Kohana::show_404();

		if (!$this->input->post('title'))
		{
			$menu_items = $this->page->get_menu_list();
			$this->layout->header = $this->load->view('header', array_merge($this->header, array('title' => "Add A Page")));
			$this->layout->content = $this->load->view('page/add_page', array('pages' => $menu_items));

			$this->layout->render(TRUE);
		}
		else
		{
			if ($this->page->add_page($this->input->post()))
				url::redirect('page/list_pages');
			else
				throw new Kohana_Exception('page.add');
		}
	}

	function list_pages()
	{
		if (!$this->auth->check_logged_in())
			Kohana::show_404();

		$this->layout->header = $this->load->view('header', array_merge($this->header, array('title' => "List Pages")));
		$this->layout->content = $this->load->view('page/list_pages', array('pages' => $this->page->get_pages()));

		$this->layout->render(TRUE);
	}

	function delete()
	{
		if (!$this->auth->check_logged_in())
			Kohana::show_404();

		if ($this->page->delete($this->uri->segment(3)))
		{
			url::redirect('page/list_pages');
		}
		else
			throw new Kohana_Exception('page.delete');
	}

	function check_filename()
	{
		$filename = $this->input->get('filename');
		$old_filename = $this->input->get('old_filename');

		if ($filename == $old_filename)
		{
			die('success');
		}
		if (preg_match('|['.preg_quote('* !@#$%&/\()').']|', $filename) or $filename == '' or ($old_filename == 'index' and $filename != 'index'))
		{	
			die('Bad Filename');
		}
		$query = $this->db->from('pages')->where('filename', $filename)->get();

		if ($query->num_rows() > 0)
			die('Duplicate Filename');
		else
			die('success');
	}

	function contact_us()
	{
	    $this->load->library("forge");
        $conf["action"] = "contact_us";
        $conf["form_name"] = "Contact Us";
        $conf["form_id"] = "contact_us";

        $this->forge->initialize($conf);

        $default = array("rules" => "trim|required[4,255]");

        $this->forge->add("name",           "text",     array('rules' => 'required'));
        $this->forge->add("address",        "text",     array());
        $this->forge->add("email",          "text",     array('rules' => 'required'));
        $this->forge->add("phone_number",   "text",     array('rules' => 'required'));
        $this->forge->add("comments",       "textarea", array('rows' => '5', 'cols' => '30'));
        $this->forge->add("send",           "submit",   array('value' => 'Send Email'));

        if ($post = $this->forge->post_data()) 
        {
            /* Include the Swift Mailer files */
        	include Kohana::find_file('vendor', 'swift/swift');
            include Kohana::find_file('vendor', 'swift/Swift/Connection/SMTP');

            /* Initiate the connection */
            $this->swift =& new Swift(new Swift_Connection_SMTP("mail.imagemanagement.com"));

            /* Set the body */
            $message_body = "<h3>This is an automated message from www.radd-cpa.org</h3>
<p>You have received the following contact message:</p>
<p>Name: " . $post['name'] . "</p>
<p>Email: " . $post['email'] . "</p>
<p>Address: " . $post['address'] . "<p>
<p>Phone Number: " . $post['phone_number'] . "</p>
<p>Message:<br />" . $post['comments'].'</p>';
            
            /* Make the message */
            $message =& new Swift_Message('WebSite Contact Request', $message_body, "text/html");
            
            /* And try and send it */
            if ($this->swift->send($message, 'jeremy@imagemanagement.com', new Swift_Address($post['email'], $post['name'])))
            	url::redirect('contact_success');
            else
            	throw new Kohana_Exception('swift.general_error');
        }
        else
        {
            if ($page_content = $this->page->get_page($this->location))
			{    
	            $this->layout->header = $this->load->view('header', array_merge($this->header, array('title' => "$page_content->title)));
				$this->layout->content = $this->load->view('page/contact_us', array('page' => $page_content));
					
				$this->layout->render(TRUE);
			}
			else
				Kohana::show_404();
		}
	}
}