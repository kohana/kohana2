<?php defined('SYSPATH') or die('No direct script access.');

$config['_default'] = 'page';

$config['contact_us'] = 'page/contact_us';

$config['page/([A-Za-z0-9_]+)'] = "page/$1";
$config['page/([A-Za-z0-9_]+)/([A-Za-z0-9_]+)'] = "page/$1/$2";
$config['page/([A-Za-z0-9_]+)/([A-Za-z0-9_]+)/([A-Za-z0-9_]+)'] = "page/$1/$2";

$config['user/([A-Za-z0-9_]+)'] = "user/$1";

$config['store'] = "store/index";
$config['store/edit/:any'] = 'page/edit';
$config['store/([A-Za-z0-9_]+)'] = "store/$1";
$config['store/([A-Za-z0-9_]+)/([A-Za-z0-9_]+)'] = "store/$1/$2";

$config['shoppingcart'] = "shoppingcart/index";
$config['shoppingcart/([A-Za-z0-9_]+)'] = "shoppingcart/$1";

$config['care'] = "page/care";

$config[':any'] = "page/index";