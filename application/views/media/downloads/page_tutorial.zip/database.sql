-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 09, 2007 at 12:05 PM
-- Server version: 5.0.13
-- PHP Version: 5.2.3
-- 
-- Database: `example`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `pages`
-- 

CREATE TABLE `pages` (
  `id` mediumint(9) NOT NULL auto_increment,
  `page_name` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `menu` tinyint(1) NOT NULL default '0',
  `filename` varchar(255) NOT NULL,
  `order` mediumint(9) NOT NULL,
  `date` int(11) NOT NULL,
  `child_of` mediumint(9) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `filename` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `pages`
-- 

INSERT INTO `pages` VALUES (1, 'Home', 'Home', '', 1, 'index', 1, 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `userid` int(11) NOT NULL auto_increment,
  `username` char(16) NOT NULL,
  `fullname` char(100) NOT NULL,
  `email` char(100) NOT NULL,
  `password` char(40) NOT NULL,
  `lastlogin` int(11) NOT NULL,
  `enabled` int(1) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `users`
-- 

