<?php

 $no_edit = array("add", "edit", "details", "store");

 /* Set this page for the login redirections */
 if ($this->uri->segment(1) != "user" and $this->uri->segment(2) != "edit")
 {
 	$this_page = $_SERVER["REQUEST_URI"];
 	$this->session->set(array("last_page" => $this_page));
 }
 if ($this->session->get("loggedin") and !in_array($this->uri->segment(1), $no_edit))
 	echo html::anchor(($this->uri->rsegment(1) != "") ? $this->uri->rsegment(1) : "page") . "/edit/" . $this->uri->segment(1) . (($this->uri->segment(2) !== false) ? ("/" . $this->uri->segment(2)) : "", "Edit this page");

?>
</div>
<div id="footer">
	<p>&copy; Copyright 2007 Kohana</p>
</div>

<?php if (!$this->session->get("loggedin")):?><h3><?=html::anchor("user/login", "LOGIN")?><?php endif; ?>
<?php if ($this->session->get("loggedin")):?><h3><?=html::anchor("user/logout", "Logout")?></h3>
	<h3><?=html::anchor("page/list_pages", "Page Administration")?></h3><?php endif; ?>
</body>
</html>