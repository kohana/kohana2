<?=$page->content?>
<?=$this->forge->build()?>