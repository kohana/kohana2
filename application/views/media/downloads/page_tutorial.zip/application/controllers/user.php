<?php
/*
 * Class: User_Controller
 *  
 * Kohana Source Code:
 *  author    - Jeremy Bush
 *  copyright - (c) 2007 Jeremy Bush
 *  license   - <http://kohanaphp.com/license.html>
 *
 * Table Structure:
 *  CREATE TABLE `users` (
 *  `userid` int( 11 ) NOT NULL AUTO_INCREMENT ,
 *  `username` char( 16 ) NOT NULL ,
 *  `fullname` char( 100 ) NOT NULL ,
 *  `email` char( 100 ) NOT NULL ,
 *  `password` char( 40 ) NOT NULL ,
 *  `lastlogin` int( 11 ) NOT NULL ,
 *  `enabled` int( 1 ) NOT NULL ,
 *  `admin` tinyint( 1 ) NOT NULL ,
 *  PRIMARY KEY ( `userid` ) ,
 *  UNIQUE KEY `username` ( `username` )
 *  ) ENGINE = InnoDB DEFAULT CHARSET = utf8;
 */

class User_Controller extends Controller {
 
	var $header = '';

	function __construct()
	{
		parent::__construct();
		$this->load->model('page');
		$this->header = array('menu' => $this->page->get_menu(), 'title' => "radd-cpa.org :: Home");
	}

	function index()
	{
		return $this->login();
	}

	function login()
	{
		$layout = $this->load->view('layout');

		$layout->header = $this->load->view('header', $this->header);
		$layout->content = $this->load->view('user/loginform', array());
		$layout->footer = $this->load->view('footer', array('menu' => $this->page->get_menu()));

		$username = $this->input->post('username');
		$password = $this->input->post('password');
		if( $username && $password )
		{
			if( $this->auth->try_login($username, $password))
				url::redirect(str_replace('.html', '', $this->session->get('last_page')));
			else
				$layout->content = $this->load->view('user/failure', array());
		} 

		$layout->render(TRUE);
	}

	function logout()
	{
		$this->auth->logout();

		url::redirect(str_replace('.html', '', $this->session->get('last_page')));
	}
}