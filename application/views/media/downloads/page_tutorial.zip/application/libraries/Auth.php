<?php defined('SYSPATH') or die('No direct script access.');
/*
 * Class: Auth
 *  Performs basic user authentication
 *
 * Kohana Source Code:
 *  author    - Jeremy Bush
 *  copyright - (c) 2007 Jeremy Bush
 *  license   - <http://kohanaphp.com/license.html>
 *
 */
class Auth_Core {

	var $router;
	var	$keyval	= array();

	/**
	 * Constructor
	 *
	 * @access	public
	 */		
	function __construct()
	{
		$this->kohana =& Kohana::instance();
		
		Log::add('debug', 'Auth Class Initialized');
	}
	
	// --------------------------------------------------------------------
	
	/**
	 * Try the login with supplied user credentials
	 *
	 * @access	public
	 * @return	bool
	 */
	function try_login($username, $password)
	{
		$query = $this->kohana->db->from('users')->where('username', $username)->where('password', sha1($password))->get();
		
		
		if (count($query) == 1)
		{
			$userdata = $query->current();
			
			$extra_data = array(	'loggedin' 		=> true,
									'username' 		=> $username,
									'user_agent'	=> $this->kohana->user_agent->agent_string(),
									'last_activity'	=> time());
					
			$this->kohana->session->set(array_merge($extra_data, $userdata));
	
			/* Update the last login */
			$this->kohana->db->update('users', array('lastlogin' => time()), array('username' => $username));
			return TRUE;
		}
		else
			return FALSE;
	}
	
	/**
	 * Log the current user out, and destroy the cookie and db session row
	 *
	 * @access	public
	 * @return	bool
	 */
	function logout()
	{
		$extra_data = array(	'loggedin' 		=> false,
								'username' 		=> null,
								'fullname' 		=> null,
								'address' 		=> null,
								'city'			=> null,
								'state'			=> null,
								'zip'			=> null,
								'lastlogin'		=> null,
								'ip_address'	=> null,
								'user_agent'	=> null,
								'last_activity'	=> null);
					
		$this->kohana->session->set($extra_data);
		
		return true;
	}
	
	function check_logged_in()
	{
		return $this->kohana->session->get('loggedin');
	}
}