<?php
/*
 * Class: Page_Model
 *  Does work on the Page table
 *
 * Kohana Source Code:
 *  author    - Jeremy Bush
 *  copyright - (c) 2007 Jeremy Bush
 *  license   - <http://kohanaphp.com/license.html>
 *
 * Table Structure:
 *  CREATE TABLE `pages` (
 *  `id` mediumint( 9 ) NOT NULL AUTO_INCREMENT ,
 *  `page_name` varchar( 100 ) NOT NULL ,
 *  `title` varchar( 255 ) NOT NULL ,
 *  `content` longtext NOT NULL ,
 *  `menu` tinyint( 1 ) NOT NULL default '0',
 *  `filename` varchar( 255 ) NOT NULL ,
 *  `order` mediumint( 9 ) NOT NULL ,
 *  `date` int( 11 ) NOT NULL ,
 *  `child_of` mediumint( 9 ) NOT NULL default '0',
 *  PRIMARY KEY ( `id` ) ,
 *  UNIQUE KEY `filename` ( `filename` )
 *  ) ENGINE = MYISAM DEFAULT CHARSET = utf8 PACK_KEYS =0;
 *
 *  INSERT INTO `pages` ( `id` , `page_name` , `title` , `content` , `menu` , `filename` , `order` , `date` , `child_of` ) 
 *  VALUES (  NULL , 'Home', 'Home', 'index', '1', '', '1', '0', '0' );
 */
class Page_Model extends Model {
	
	function get_page_id($page_name)
	{
		$query = $this->db->from('pages')->where('filename', $page_name)->get();
		
		return (count($query) > 0) ? $query->current()->id : 0;
	}

	function get_page($page)
	{
		if (isset($page['child']))
		{
			$child_id = $this->get_page_id($page['parent']);
			$query = $this->db->from('pages')->where(array('filename' => $page['child'], 'child_of' => $child_id))->limit('1')->get();			
		}
		else
		{
			$query = $this->db->from('pages')->where('filename', $page['parent'])->limit('1')->get();
		}

		/* Check to see if the page exists */
		if (count($query) > 0)
			return $query->current();
		else
			return false;
	}

	function get_pages() /* Get all the pages */
	{
		$query = $this->db->from('pages')->where('child_of', '0')->get();
		
		$pages = array();
		
		foreach ($query as $row)
		{
			$pages[$row->id] = array();
			$pages[$row->id][] = $row;
			$query2 = $this->db->from('pages')->where('child_of', $row->id)->get();
			
			foreach ($query2 as $sub_row)
				$pages[$row->id][] = $sub_row;
		}
		
		return $pages;
	}

	function add_page($data) /* Insert a page into the system */
	{
		$insert_data = array(	
						'title'     => $data['title'],
						'page_name' => $data['page_name'],
						'content'   => $data['content'],
						'filename'  => $data['filename'],
						'menu'      => isset($data['menu']) ? $data['menu'] : 0,
						'child_of'  => $data['child_of'],
						'date'      => time()
						);
			
		$query = $this->db->insert('pages', $insert_data);
		
		return $query->insert_id();
	}

	function edit_page($data) /* Edits the content of the page */
	{
		$update_data = array(
						'title'     => $data['title'],
						'page_name' => $data['page_name'],
						'content'   => $data['content'],
						'filename'  => $data['filename'],
						'menu'      => isset($data['menu']) ? $data['menu'] : 0,
						'child_of'  => $data['child_of'],
						'date'      => time(),
						'order'     => isset($data['order']) ? $data['order'] : 0
						);
		$query = $this->db->update('pages', $update_data, array('id' => $data['id']));
		return count($query);
	}

	function get_menu() /* Returns menus */
	{
		$query = $this->db->from('pages')->where('menu', TRUE)->where('child_of', 0)->orderby('order')->get();
		
		$menu = array();
		$submenu = array();
		foreach ($query as $row)
		{
			$menu[$row->filename] = $row->page_name;
			
		}
		
		$query = $this->db->from('pages')->where('child_of', 0)->get();
		foreach ($query as $row)
		{
			$query2 = $this->db->from('pages')->where('child_of', $row->id)->where('menu', TRUE)->get();
			foreach ($query2 as $subrow)
				$submenu[$row->filename][$subrow->filename] = $subrow->page_name;
		}
		return array('menu' => $menu, 'submenu' => $submenu);
	}

	function get_menu_list()
	{
		$query = $this->db->from('pages')->where('child_of', 0)->orderby('order')->get();
		
		$menus = array(0 => 'Heading');
		foreach ($query as $row)
			$menus[$row->id] = $row->page_name;
		return $menus;
	}

	function delete($id)
	{
		return $this->db->delete('pages', array('id' => $id));
	}
}
?>